<?php

namespace StoradeProviders\Csv;

class Storage {
}
