<?php

namespace StoradeProviders\JSON;

class Storage {
}
