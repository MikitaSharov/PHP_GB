<?php

var_dump($_SERVER['argv']);